from flask import Flask, render_template, request, redirect
from pymongo import MongoClient

app = Flask(__name__)

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client['flask_db']
collection = db['users']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    name = request.form['name']
    email = request.form['email']

    # Insert into MongoDB
    collection.insert_one({'name': name, 'email': email})
    
    return render_template('success.html', name=name)

if __name__ == '__main__':
    app.run(debug=True)
